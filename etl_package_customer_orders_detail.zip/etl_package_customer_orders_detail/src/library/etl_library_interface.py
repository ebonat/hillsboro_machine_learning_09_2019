
from zope.interface import Interface

class ETLLibraryInterface(Interface):    
    '''
    etl library interface class
    '''
    def sqlserver_open_connection_d2i(self, timeout=15):
        pass
    def sqlserver_open_connection_tf_ds(self, timeout=15):    
        pass
    def sqlserver_open_connection_home(self, timeout=15):    
        pass
    def sqlserver_close_connection(self, sqlserver_connection):
        pass
    def sqlserver_cursor_select(self, sqlserver_connection, sql, sql_parameters=None):
        pass
    def sqlserver_cursor_transaction(self, sqlserver_connection, sql, parameters=None):
        pass
    def sqlserver_close_cursor(self, sqlserver_cursor):
        pass
    def get_exception_message(self):
        pass
    def print_exception_message(self, message_orientation="horizontal"):
        pass
    def logging_exception_message(self, message_orientation="horizontal"):
        pass
    def b64decode_string(self, b64encode_string):
        pass
    def write_log_file(self, event_level, message):
        pass
    def read_app_config_file(self, section_name, option_name):
        pass
    def write_app_config_file(self, section_name, option_name, option_value):
        pass