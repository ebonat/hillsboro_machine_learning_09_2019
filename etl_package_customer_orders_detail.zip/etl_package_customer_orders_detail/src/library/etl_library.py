
import sys
import os
import traceback
import datetime
import time
import logging

import pyodbc
import config
import base64
import configparser 

from zope.interface import implementer
from library.etl_library_interface import ETLLibraryInterface

@implementer(ETLLibraryInterface)
class ETLLibrary(object):

    def __init__(self, app_config_file=None, app_log_file=None):
        if app_config_file is not None:
            self.app_config_file = app_config_file
        if app_log_file is not None:
            self.app_log_file = app_log_file
        
    def sqlserver_open_trusted_connection(self, timeout=15):    
        """
        get sql server odbc connection object for d2i server
        :param timeout: connection object time out
        :return sql server connection object
        """
        try:            
            connection_string = "DRIVER={SQL Server};"\
                                          "SERVER="+self.read_app_config_file("sql_server_home", "server")+";"\
                                          "DATABASE="+self.read_app_config_file("sql_server_home", "database")+";"\
                                          "Trusted_Connection=yes;"
            sqlserver_connection = pyodbc.connect(connection_string)
            sqlserver_connection.timeout = timeout                    
        except:     
            sqlserver_connection = None
            self.logging_exception_message()             
        return sqlserver_connection
        
    def sqlserver_open_connection(self, timeout=15):    
        """
        get sql server odbc connection object for tf ds server
        :param timeout: connection object time out
        :return sql server connection object
        """        
        try:                   
            connection_string = "DRIVER={SQL Server};"\
                                          "SERVER="+self.read_app_config_file("sql_server_home", "server")+";"\
                                          "DATABASE="+self.read_app_config_file("sql_server_home", "database")+";"\
                                          "UID="+self.read_app_config_file("sql_server_home", "uid")+";"\
                                          "PWD="+self.read_app_config_file("sql_server_home", "pwd")+";"            
            sqlserver_connection = pyodbc.connect(connection_string)
            sqlserver_connection.timeout = timeout                    
        except:                
            sqlserver_connection = None
            self.logging_exception_message()
        return sqlserver_connection     
    
    def sqlserver_close_connection(self, sqlserver_connection):
        """
        close sql server connection object
        :sqlserver_connection sql server connection object
        :return none
        """
        try:            
            if (sqlserver_connection is not None):
                sqlserver_connection.close()        
        except:     
            self.logging_exception_message()
   
    def sqlserver_cursor_select(self, sqlserver_connection, sql, sql_parameters=None):
        """
        execute select sql statements
        :param sqlserver_connection: sql serer database connection object
        :param sql: sql select statement
        :param sql_parameters: tuple of sql parameters
        :return data row, data column and data error 
        """                 
        data_row, data_column, data_error = (None, None, None)          
        try:    
            sqlserver_cursor = sqlserver_connection.cursor()    
            if sql_parameters is not None:    
                sqlserver_cursor.execute(sql, sql_parameters)
            else:
                sqlserver_cursor.execute(sql) 
            data_row = sqlserver_cursor.fetchall()   
            data_column = [column[0] for column in sqlserver_cursor.description]            
            if len(data_row) == 0:
                if sqlserver_cursor.nextset():
                    data_error = sqlserver_cursor.fetchone()[0]                                                
        except:     
            self.logging_exception_message()
        finally:
            self.sqlserver_close_cursor(sqlserver_cursor)            
        return data_row, data_column, data_error        
    
    def sqlserver_cursor_transaction(self, sqlserver_connection, sql, parameters=None):
        '''        
        execute transaction sql statements (insert, update and delete)
        :param sqlserver_connection: sql serer database connection object
        :param sql: sql select statement
        :param sql_parameters: tuple of sql parameters
        :return is transaction: true of false
        '''
        is_transaction = True
        try:    
            sqlserver_cursor = sqlserver_connection.cursor()    
            if parameters is not None:    
                sqlserver_cursor.execute(sql, parameters)
            else:
                sqlserver_cursor.execute(sql)                         
            sqlserver_connection.commit()
        except:     
            is_transaction = False
            self.logging_exception_message()
        finally:
            self.sqlserver_close_cursor(sqlserver_cursor)       
        return is_transaction
          
    def sqlserver_close_cursor(self, sqlserver_cursor):
        """
        close sql server cursor cursor object
        :param sqlserver_cursor: sql server cursor
        :return none
        """
        try:                
            if sqlserver_cursor is not None:  
                sqlserver_cursor.close()                           
        except:     
            self.logging_exception_message()    
                            
    def get_exception_message(self):
        """
        get exception message
        :return exception_message
        """
        exception_message = None
        try:    
            exc_type, exc_value, exc_tb = sys.exc_info()    
            file_path_name, line_number, procedure_name, line_code = traceback.extract_tb(exc_tb)[-1]
            exception_message = ''.join('[time stamp]: ' + str(datetime.datetime.now()) + ' ' 
                                        + '[error type]: ' + str(exc_type) + ' ' 
                                        + '[error value]: ' + str(exc_value) + ' ' 
                                        + '[file path name]: ' + str(file_path_name) + ' ' 
                                        + '[line number]: ' + str(line_number) + ' ' 
                                        + '[procedure name]: ' + str(procedure_name) + ' ' 
                                        + '[line of code]: ' + str(line_code))                   
        except Exception:
            exception_message = str(Exception)          
        return exception_message 
    
    def print_exception_message(self, message_orientation="horizontal"):
        """
        print full exception message
        :param message_orientation: horizontal or vertical
        :return none
        """
        try:
            exc_type, exc_value, exc_tb = sys.exc_info()            
            file_name, line_number, procedure_name, line_code = traceback.extract_tb(exc_tb)[-1]       
            time_stamp = " [Time Stamp]: " + str(time.strftime("%Y-%m-%d %I:%M:%S %p")) 
            file_name = " [File Name]: " + str(file_name)
            procedure_name = " [Procedure Name]: " + str(procedure_name)
            error_message = " [Error Message]: " + str(exc_value)        
            error_type = " [Error Type]: " + str(exc_type)                    
            line_number = " [Line Number]: " + str(line_number)                
            line_code = " [Line Code]: " + str(line_code) 
            if (message_orientation == "horizontal"):
                print( "An error occurred:{};{};{};{};{};{};{}".format(time_stamp, file_name, procedure_name, error_message, error_type, line_number, line_code))
            elif (message_orientation == "vertical"):
                print( "An error occurred:\n{}\n{}\n{}\n{}\n{}\n{}\n{}".format(time_stamp, file_name, procedure_name, error_message, error_type, line_number, line_code))
            else:
                pass                    
        except:
            self.logging_exception_message()   
            
    def logging_exception_message(self, message_orientation="horizontal"):
        """
        print full exception message
        :param message_orientation: horizontal or vertical        
        """
        exception_message = None
        try:
            exc_type, exc_value, exc_tb = sys.exc_info()            
            file_name, line_number, procedure_name, line_code = traceback.extract_tb(exc_tb)[-1]       
            time_stamp = " [Time Stamp]: " + str(time.strftime("%Y-%m-%d %I:%M:%S %p")) 
            file_name = " [File Name]: " + str(file_name)
            procedure_name = " [Procedure Name]: " + str(procedure_name)
            error_message = " [Error Message]: " + str(exc_value)        
            error_type = " [Error Type]: " + str(exc_type)                    
            line_number = " [Line Number]: " + str(line_number)                
            line_code = " [Line Code]: " + str(line_code) 
            if (message_orientation == "horizontal"):
                exception_message = "An error occurred:{};{};{};{};{};{};{}".format(time_stamp, file_name, procedure_name, error_message, error_type, line_number, line_code)
            elif (message_orientation == "vertical"):
                exception_message = "An error occurred:\n{}\n{}\n{}\n{}\n{}\n{}\n{}".format(time_stamp, file_name, procedure_name, error_message, error_type, line_number, line_code)
            else:
                pass      
            self.write_log_file("error", exception_message)                         
        except:
            exception_message = sys.exc_info()[0]
            self.write_log_file("error", exception_message)        
       
    def b64decode_string(self, b64encode_string):
        """
        decode the b64 encode string
        :param b64encode_string: b64 encode string
        :return dencode string
        """
        dencode_string = None
        try:
            dencode_string = base64.b64decode(b64encode_string)
            dencode_string = dencode_string.decode("utf-8")            
        except:
            self.logging_exception_message()   
        return dencode_string

    def write_log_file(self, event_level, message):
        """
         write messages to a log file       
        :param event_level: even level name (CRITICAL, DEBUG, ERROR, INFO and WARNING)
        :param message: message to be written 
        :return None
        """       
        try:            
            logging_format_message = self.read_app_config_file("logging_format", "logging_format_message")
            logging_format_datetime = self.read_app_config_file("logging_format", "logging_format_datetime")
            if event_level == "CRITICAL".lower():
                logging.basicConfig(format=logging_format_message, datefmt=logging_format_datetime, 
                                    filename=self.app_log_file, level=logging.CRITICAL)  
                logging.critical(message)        
            elif event_level == "ERROR".lower():
                logging.basicConfig(format=logging_format_message, datefmt=logging_format_datetime, 
                                    filename=self.app_log_file, level=logging.ERROR)      
                logging.error(message)
            elif event_level == "WARNING".lower():
                logging.basicConfig(format=logging_format_message, datefmt=logging_format_datetime, 
                                    filename=self.app_log_file, level=logging.WARNING)      
                logging.warning(message)   
            elif event_level == "INFO".lower():
                logging.basicConfig(format=logging_format_message, datefmt=logging_format_datetime, 
                                    filename=self.app_log_file, level=logging.INFO)      
                logging.info(message)
            elif event_level == "DEBUG".lower():
                logging.basicConfig(format=logging_format_message, datefmt=logging_format_datetime, 
                                    filename=self.app_log_file, level=logging.DEBUG)      
                logging.debug(message)                        
        except:
            self.get_exception_message()          
        
    def read_app_config_file(self, section_name, option_name):
        """
        read from application configuration file       
        :param section_name: section header name
        :param option_name: option value
        """
        option_value = None
        try:  
            config_parser = configparser.ConfigParser()
            config_parser.read(self.app_config_file)                
            option_value = config_parser.get(section_name, option_name)                        
        except:
            self.logging_exception_message()             
        return option_value
    
    def write_app_config_file(self, section_name, option_name, option_value):
        """
         write to application configuration file      
        :param section_name: section header name
        :param option_name: option name
        :param option_value: option value
        """        
        try:  
            config_parser = configparser.ConfigParser()
            config_parser.read(self.app_config_file)                            
            if not config_parser.has_section(section_name):            
                config_parser.add_section(section_name)     
            config_parser.set(section_name, option_name, option_value)            
            with open(self.app_config_file, 'w') as open_config_file:
                config_parser.write(open_config_file)            
        except:
            self.logging_exception_message()             
        finally:
            open_config_file.close()
            
    
    