USE [Northwind]
GO
/****** Object:  StoredProcedure [dbo].[CustomerOrdersDetail]    Script Date: 9/25/2019 10:59:57 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CustomerOrdersDetail] 
(
	@OrderID int, 
	@ErrorMessage VARCHAR(MAX) OUTPUT
)
AS
BEGIN	TRY
	SET NOCOUNT ON;
	SELECT ProductName, 
		O.UnitPrice,
		Quantity,
		Discount
	FROM Products P, [Order Details] O
	WHERE O.ProductID = P.ProductID 
	AND O.OrderID = @OrderID
END TRY
BEGIN CATCH
	SET  @ErrorMessage = 'An error occurred: ' + ERROR_PROCEDURE() + ', ' + 
	CAST(ERROR_LINE() AS VARCHAR(50)) + ', ' + 
	ERROR_MESSAGE();
END CATCH; 