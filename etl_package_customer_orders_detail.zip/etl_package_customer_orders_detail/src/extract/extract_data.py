
from library.etl_library import ETLLibrary
from zope.interface import implementer
from extract.extract_data_interface import ExtractDataInterface

@implementer(ExtractDataInterface)
class ExtractData(ETLLibrary):

    def __init__(self, app_config_file, app_log_file):
        super().__init__(app_config_file, app_log_file)                                
        self.app_config_file = app_config_file
        self.app_log_file = app_log_file
    
    def customer_orders_detail_extract_sp(self):       
        data_row, data_column, data_error = (None, None, None)          
        try:
#             get sql server connection object
            sqlserver_connection = self.sqlserver_open_trusted_connection()
#             check for database connection 
            if sqlserver_connection is not None:
#                 set stored procedure srting and parameters
                procedure_string = '''\
                    DECLARE @ErrorMessage varchar(max)
                    EXEC [dbo].[CustomerOrdersDetail] @OrderID = ?, @ErrorMessage = @ErrorMessage OUTPUT
                    SELECT @ErrorMessage AS '@ErrorMessage'
                '''
#                 set customer order id parameter
                customer_order_id = int(self.read_app_config_file("stored_procedure_input_parameter", "customer_order_id"))
                procedure_parameter = (customer_order_id,)              
#                 get data row, column and error if any
                data_row, data_column, data_error = self.sqlserver_cursor_select(sqlserver_connection, procedure_string, procedure_parameter)                         
        except:     
            self.logging_exception_message()               
        finally:
            self.sqlserver_close_connection(sqlserver_connection)
        return data_row, data_column, data_error

# USE [Northwind]
# GO
# /****** Object:  StoredProcedure [dbo].[CustomerOrdersDetail]    Script Date: 9/23/2019 7:24:52 PM ******/
# SET ANSI_NULLS ON
# GO
# SET QUOTED_IDENTIFIER ON
# GO
# ALTER PROCEDURE [dbo].[CustomerOrdersDetail] 
# (
#     @OrderID INT, 
#     @ErrorMessage VARCHAR(MAX) OUTPUT
# )
# AS
# BEGIN    TRY
#     SET NOCOUNT ON;
#     SELECT ProductName, 
#         O.UnitPrice,
#         Quantity,
#         Discount
#     FROM Products P, [Order Details] O
#     WHERE O.ProductID = P.ProductID 
#     AND O.OrderID = @OrderID; --10248
# END TRY
# BEGIN CATCH
#         SET  @ErrorMessage = 'An error occurred: ' + ERROR_PROCEDURE() + ', ' + 
#             CAST(ERROR_LINE() AS VARCHAR(50)) + ', ' + 
#             ERROR_MESSAGE();
# END CATCH; 


