
from zope.interface import Interface

class ExtractDataInterface(Interface):
    '''
    extract data interface class
    '''
    def customer_orders_detail_extract_sp(self): 
        pass