
# EXE FILE CREATION AND TEST
# 1. change to src directory
# cd C:\Users\Ernest\workspace\etl_package_customer_orders_detail\src
# 2. run the pyinstaller to build the exe on dist directory
    # 2.1 rum from command line
    # pyinstaller --onedir --name=etl_installer "C:\Users\Ernest\workspace\etl_package_customer_orders_detail\src\etl.py"
    # 2.2 run  from windows explorer
    #pyinstaller --onedir --name=etl_installer windowed "C:\Users\Ernest\workspace\etl_package_customer_orders_detail\src\etl.py"
    #2.3 add config_old and log folders and files to exe dist folder
    # pyinstaller --onedir --name=etl_installer --windowed "C:\Users\Ernest\workspace\etl_package_customer_orders_detail\src\etl.py" --add-data "C:\Users\Ernest\workspace\etl_package_customer_orders_detail\src\config_old\app.cfg;config_old" --add-data "C:\Users\Ernest\workspace\etl_package_customer_orders_detail\src\log\app.log;log"
# 3. run the exe to test it 
    # 3.1 from the command line
    # C:\Users\Ernest\workspace\etl_package_customer_orders_detail\src\dist\etl_installer\etl_installer.exe
    # 3.2 from windows explorer
    # double-click on the exe file

# Testing Your New Executable
# https://realpython.com/pyinstaller-python/#customizing-your-builds

import time
import datetime
import os
import sys
# import config_old
import pandas as pd

from extract.extract_data  import ExtractData
from transform.transform_data  import TransformData
from load.load_data  import LoadData
from library.etl_library import ETLLibrary

# Calling Stored Procedures
# https://github.com/mkleehammer/pyodbc/wiki/Calling-Stored-Procedures

def main():    
#     get default app config_old and log files
    app_directory = os.path.dirname(__file__)          
    app_config_file = os.path.join(app_directory, "config\\app.cfg")   
    app_log_file = os.path.join(app_directory, "log\\app.log")   

#     instantiate etl etl_library
    etl_library = ETLLibrary(app_config_file, app_log_file)
    
#     set file time stamp 
    time_stamp_format = etl_library.read_app_config_file("file", "time_stamp")
    time_stamp_file = datetime.datetime.now().strftime(time_stamp_format)
    
#     etl process started
    etl_library.write_log_file("info", "etl process started.")
    
#     1. DATA EXTRACT TIER
    etl_library.write_log_file("info", "extract data started.")
    extract_data = ExtractData(app_config_file, app_log_file)    
    data_row, data_column, data_error = extract_data.customer_orders_detail_extract_sp()
    if (data_error is not None):
        etl_library.write_log_file("error", "extract data ended. " + str(data_error))
        exit()
    if (data_row is None):
        etl_library.write_log_file("info", "extract data ended. no data was extracted.")
        exit() 
    else:
        if (len(data_row)) == 0:
            etl_library.write_log_file("info", "extract data ended. no data was extracted.")
            exit()                 
    etl_library.write_log_file("info", "extract data ended.")
      
#     2 DATA TRANSFORM (PREPROCESSING) TIER
    etl_library.write_log_file("info", "transform data started.")
    transform_data = TransformData(app_config_file, app_log_file)
    df_customer_orders, is_transform = transform_data.customer_orders_detail_transform(data_row, data_column)    
    if (df_customer_orders is None) or (is_transform == False):
        etl_library.write_log_file("info", "transform data ended. no data was transformed.")
        exit()        
    etl_library.write_log_file("info", "transform data ended")
      
#     3. DATA LOAD TIER
    etl_library.write_log_file("info", "load data started.")
    load_data =  LoadData(app_config_file, app_log_file)    
    data_directory = etl_library.read_app_config_file("directory", "data_directory")
    app_file_name = etl_library.read_app_config_file("file", "app_file_name")
    csv_file_name = app_file_name + time_stamp_file + ".csv"      
    csv_file_path_name = os.path.join(data_directory, csv_file_name)        
    is_file = load_data.customer_orders_detail_to_file(df_customer_orders,  csv_file_path_name)
    if is_file == False:
        etl_library.write_log_file("info", "data load ended. no file was created.")        
    else:
        etl_library.write_log_file("info", "csv file '{}' has been created.".format(csv_file_name))
    etl_library.write_log_file("info", "load data ended.")
                 
#     etl process ended
    etl_library.write_log_file("info", "etl process ended.")    
    
if __name__ == '__main__':
    start_time = time.clock()
    main()
    end_time = time.clock()
    diff_time = end_time - start_time
    result = time.strftime("%H:%M:%S", time.gmtime(diff_time)) 
    print("program runtime: {}".format(result))
