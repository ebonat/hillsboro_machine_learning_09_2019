
from zope.interface import Interface

class TransformDataInterface(Interface):
    
    def customer_orders_detail_transform(self, data_row, data_column):
        pass