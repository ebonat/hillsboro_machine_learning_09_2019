
import pandas as pd
from library.etl_library import ETLLibrary
from zope.interface import implementer
from transform.transform_data_interface import TransformDataInterface

@implementer(TransformDataInterface)
class TransformData(ETLLibrary):

    def __init__(self, app_config_file, app_log_file):
        super().__init__(app_config_file, app_log_file)                                
        self.app_config_file = app_config_file
        self.app_log_file = app_log_file
                
    def customer_orders_detail_transform(self, data_row, data_column):   
        df_customer_orders = None
        is_transform = True
        try:           
#             create pandas data frame from data row and column                    
            df_customer_orders = pd.DataFrame.from_records(data=data_row, columns=data_column)     
#             data convertion and rounding 
            decimal_place = int(self.read_app_config_file("preprocessing", "decimal_place"))
            df_customer_orders["UnitPrice"] = df_customer_orders["UnitPrice"].astype(float).round(decimals=decimal_place)
            df_customer_orders["Quantity"] = df_customer_orders["Quantity"].astype(int)
            df_customer_orders["Discount"] = df_customer_orders["Discount"].astype(float).round(decimals=decimal_place)
#             calculate extended price
            df_customer_orders["ExtendedPrice"] = df_customer_orders["Quantity"] * (1 - df_customer_orders["Discount"]) * df_customer_orders["UnitPrice"]
#             add dollar sign and round extended price
            df_customer_orders["ExtendedPrice"] = "$" + (df_customer_orders["ExtendedPrice"].round(decimals=decimal_place).astype(str))
        except:     
            is_transform = False         
            self.logging_exception_message()       
        return df_customer_orders, is_transform
