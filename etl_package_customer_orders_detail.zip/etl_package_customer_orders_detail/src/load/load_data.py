
from library.etl_library import ETLLibrary
from zope.interface import implementer
from load.load_data_interface import LoadDataInterface

@implementer(LoadDataInterface)
class LoadData(ETLLibrary):
    
    def __init__(self, app_config_file, app_log_file):
        super().__init__(app_config_file, app_log_file)                                
        self.app_config_file = app_config_file
        self.app_log_file = app_log_file    

    def customer_orders_detail_to_file(self, df_data, file_path_name, file_type="csv"):    
        '''
        load data to output file
        :param df_data: data frame
        :param file_path_name: output file path and name
        :param file_type: type of the file (csv, hdf5 and json)
        :retunr is load is 'true' or 'false'
        '''
        is_load = True
        try:              
#             data load to csv, hdf5 or json file              
            if file_type == "csv":                
                df_data.to_csv(file_path_name, index=False)           
            if file_type == "hdf5":                
                df_data.to_hdf(file_path_name, key="hdf5")       
            elif file_type == "json":                
                df_data.to_json(file_path_name)                         
        except:     
            is_load = False
            self.logging_exception_message()               
        return is_load
    

    def customer_orders_detail_to_view(self, df_name, file_path_name, file_type="csv"):
        pass