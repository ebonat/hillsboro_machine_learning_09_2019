
from zope.interface import Interface

class LoadDataInterface(Interface):
    
    def customer_orders_detail_to_file(self, df_name, file_path_name, file_type="csv"):
        pass